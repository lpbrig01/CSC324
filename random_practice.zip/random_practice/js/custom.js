/********************************************************************
 * 
 * Script to insert a random image
 * upon click of a button.
 * 
 *******************************************************************/

const imageNumbers = [1, 2, 3, 4];

const button = document.querySelector("#randomizer");


button.addEventListener("click", placeRandomImage);

function placeRandomImage() {
  console.log("Selecting a random image ...");
  let image = document.querySelector("#random-image");
  let index = Math.floor(Math.random() * imageNumbers.length);
  console.log(`I randomly picked this index: ${index}`);
  let numb = imageNumbers[index];
  console.log(`In the array ${imageNumbers}, the value at index ${index} is ${numb}.`);
  let source = `images/image_${numb}.jpg`;
  console.log(`Therfore I will insert the image at this path: ${source}.`)
  image.src = `images/image_${numb}.jpg`;
 }



 
 
